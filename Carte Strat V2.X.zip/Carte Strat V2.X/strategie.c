/******************************************************************************/
/************** Carte principale Robot 1 : DSPIC33FJ128MC804*******************/
/******************************************************************************/
/* Fichier 	: srategie.c
 * Auteur  	: Quentin
 * Revision	: 1.0
 * Date		: 07 f�vrier 2015, 22:47
 *******************************************************************************
 *
 *
 ******************************************************************************/

/******************************************************************************/
/******************************** INCLUDES ************************************/
/******************************************************************************/

#include "system.h"

/******************************************************************************/
/******************************************************************************/
/******************************************************************************/

void strategie()
{
    COULEUR = couleur_depart();
    
    #ifdef GROS_ROBOT


        // Inits avant d�marage du robot :
        init_jack();
        
        while(!SYS_JACK);

        // D�marage du match
        CPT_TEMPS_MATCH.actif = true;
        EVITEMENT_ADV.actif = OFF;
        EVITEMENT_ADV.mode = STOP;
        
        brake();

        

        delay_ms(1000);   
    #endif

        
    #ifdef PETIT_ROBOT
        //id ax12
        //1 ouverture bec
        //3loquet balles adverse
        //4interupteur              250
        //11 tri des balles         630:360:0
        //12bras abeilles           750:500
        //22canon
        
        
        rejoindre(500,0,MARCHE_AVANT,1);
        EVITEMENT_ADV.actif = ON;
        EVITEMENT_ADV.mode = STOP;
        init_position_robot(0., 0., 0.); 
        
        
        #ifdef STRAT
        
        //while(!SYS_JACK);
        //CPT_TEMPS_MATCH.actif = true;

        
        rejoindre(1150,50,MARCHE_AVANT,5);//interupteur ecran
        angle_AX12(4,750,100, SANS_ATTENTE);//bras de l'interupteur
        //envoie de donn� a l'ax12(score interupteur)
        angle_AX12(4,500,100,SANS_ATTENTE);
        
        rejoindre(30,850,MARCHE_AVANT,5);//recuperateur de balle 1
        /////////////////////////////////////////////////////////////manoeuvre d'aproche  A FAIRE!!
        angle_AX12(1,0,100,SANS_ATTENTE);//ouverture du bec
        orienter(180,5);//viser le recuperateur
        //arduino turbine
        //arduino score loquet
        angle_AX12(11,630,100,SANS_ATTENTE);//1
        angle_AX12(11,360,100,SANS_ATTENTE);
        angle_AX12(11,630,100,SANS_ATTENTE);//2
        angle_AX12(11,360,100,SANS_ATTENTE);
        angle_AX12(11,630,100,SANS_ATTENTE);//3
        angle_AX12(11,360,100,SANS_ATTENTE);
        angle_AX12(11,630,100,SANS_ATTENTE);//4
        angle_AX12(11,360,100,SANS_ATTENTE);
        angle_AX12(11,630,100,SANS_ATTENTE);//5
        angle_AX12(11,360,100,SANS_ATTENTE);
        angle_AX12(11,630,100,SANS_ATTENTE);//6
        angle_AX12(11,360,100,SANS_ATTENTE);
        angle_AX12(11,630,100,SANS_ATTENTE);//7
        angle_AX12(11,360,100,SANS_ATTENTE);
        angle_AX12(11,630,100,SANS_ATTENTE);//8
        angle_AX12(11,360,100,SANS_ATTENTE);
        rejoindre(150,850,MARCHE_ARRIERE,5);//
        
        rejoindre(250,300,MARCHE_AVANT,5);//spot de tir
        angle_AX12(22,0,100,SANS_ATTENTE);//1
        //arduino tir
        angle_AX12(22,0,100,SANS_ATTENTE);
        //arduino reset
        angle_AX12(22,0,100,SANS_ATTENTE);//2
        //arduino tir
        angle_AX12(22,0,100,SANS_ATTENTE);
        //arduino reset
        angle_AX12(22,0,100,SANS_ATTENTE);//3
        //arduino tir
        angle_AX12(22,0,100,SANS_ATTENTE);
        //arduino reset
        angle_AX12(22,0,100,SANS_ATTENTE);//4
        //arduino tir
        angle_AX12(22,0,100,SANS_ATTENTE);
        //arduino reset
        angle_AX12(22,0,100,SANS_ATTENTE);//5
        //arduino tir
        angle_AX12(22,0,100,SANS_ATTENTE);
        //arduino reset
        angle_AX12(22,0,100,SANS_ATTENTE);//6
        //arduino tir
        angle_AX12(22,0,100,SANS_ATTENTE);
        //arduino reset
        angle_AX12(22,0,100,SANS_ATTENTE);//7
        //arduino tir
        angle_AX12(22,0,100,SANS_ATTENTE);
        //arduino reset
        angle_AX12(22,0,100,SANS_ATTENTE);//8
        //arduino tir
        angle_AX12(22,0,100,SANS_ATTENTE);
        //arduino reset
        //arduino score balles
        
        
        
        rejoindre(100,1950,MARCHE_AVANT,5);//preparer a pousser l'abeille
        orienter(0,5);
        angle_AX12(12,500,SANS_ATTENTE);//ouvertur du bras
        rejoindre(200,1950,MARCHE_AVANT,5);//preparer a pousser l'abeille
        angle_AX12(12,750,SANS_ATTENTE);//fermeture du bras du bras
        
        
        rejoindre(900,1300,MARCHE_AVANT,5);//aller au deuxieme interupteur
        rejoindre(2350,1300,MARCHE_AVANT,5);
        
        rejoindre(2350,1950,MARCHE_AVANT,5);//recuperation des balles
        /////////////////////////////////////////////////////////////manoeuvre d'aproche  A FAIRE!!
        angle_AX12(1,0,100,SANS_ATTENTE);//ouverture du bec
        orienter(180,5);//viser le recuperateur
        //arduino turbine
        //arduino score loquet
        angle_AX12(11,630,100,SANS_ATTENTE);//1
        angle_AX12(11,360,100,SANS_ATTENTE);
        angle_AX12(11,0,100,SANS_ATTENTE);//2
        angle_AX12(11,360,100,SANS_ATTENTE);
        angle_AX12(11,630,100,SANS_ATTENTE);//3
        angle_AX12(11,360,100,SANS_ATTENTE);
        angle_AX12(11,0,100,SANS_ATTENTE);//4
        angle_AX12(11,360,100,SANS_ATTENTE);
        angle_AX12(11,630,100,SANS_ATTENTE);//5
        angle_AX12(11,360,100,SANS_ATTENTE);
        angle_AX12(11,0,100,SANS_ATTENTE);//6
        angle_AX12(11,360,100,SANS_ATTENTE);
        angle_AX12(11,630,100,SANS_ATTENTE);//7
        angle_AX12(11,360,100,SANS_ATTENTE);
        angle_AX12(11,0,100,SANS_ATTENTE);//8
        angle_AX12(11,360,100,SANS_ATTENTE);
        
        
        rejoindre(2350,1300,MARCHE_AVANT,5);//aller a l'endroit pour vomir les balle
        rejoindre(1700,1300,MARCHE_AVANT,5);
        rejoindre(1700,1700,MARCHE_AVANT,5);
        angle_AX12(3,0,1,SANS_ATTENTE);
        angle_AX12(3,100,1,SANS_ATTENTE);///////////////////////////////////////////ajuster valeur
        
        rejoindre(1000,1300,MARCHE_AVANT,5);//aller tirer
        rejoindre(1150,50,MARCHE_AVANT,5);
        rejoindre(700,1100,MARCHE_AVANT,5);
        rejoindre(250,300,MARCHE_AVANT,5);
        angle_AX12(22,0,100,SANS_ATTENTE);//1
        //arduino tir
        angle_AX12(22,0,100,SANS_ATTENTE);
        //arduino reset
        angle_AX12(22,0,100,SANS_ATTENTE);//2
        //arduino tir
        angle_AX12(22,0,100,SANS_ATTENTE);
        //arduino reset
        angle_AX12(22,0,100,SANS_ATTENTE);//3
        //arduino tir
        angle_AX12(22,0,100,SANS_ATTENTE);
        //arduino reset
        angle_AX12(22,0,100,SANS_ATTENTE);//4
        //arduino tir
        angle_AX12(22,0,100,SANS_ATTENTE);
        //arduino reset
        angle_AX12(22,0,100,SANS_ATTENTE);//5
        //arduino tir
        angle_AX12(22,0,100,SANS_ATTENTE);
        //arduino reset
        angle_AX12(22,0,100,SANS_ATTENTE);//6
        //arduino tir
        angle_AX12(22,0,100,SANS_ATTENTE);
        //arduino reset
        angle_AX12(22,0,100,SANS_ATTENTE);//7
        //arduino tir
        angle_AX12(22,0,100,SANS_ATTENTE);
        //arduino reset
        angle_AX12(22,0,100,SANS_ATTENTE);//8
        //arduino tir
        angle_AX12(22,0,100,SANS_ATTENTE);
        //arduino reset
        //arduino score balles
        
        
        
        
        #endif
    #endif
}


void homologation()
{
    COULEUR = couleur_depart();

#ifdef GROS_ROBOT

      // Inits avant d�marage du robot :
        init_jack();
        
        while(!SYS_JACK);

        // D�marage du match
        CPT_TEMPS_MATCH.actif = true;
        EVITEMENT_ADV.actif = OFF;
        EVITEMENT_ADV.mode = STOP;

        init_position_robot(180., 988., 0.);
#endif

#ifdef PETIT_ROBOT

        init_position_robot (153, 1030, 0);

#endif

}

void reglage_odometrie()
{

    delay_ms(2000);
    //while(!SYS_JACK);
    COULEUR = couleur_depart();
#ifdef GROS_ROBOT
    init_jack();
#endif
    EVITEMENT_ADV.actif = OFF;
    
      init_position_robot (0., 0., 0.);
          //orienter(5, 100);




            init_position_robot (-100., 0., 0.);
            rejoindre(0, 0, MARCHE_AVANT, 100);
            trapeze(MARCHE_AVANT);
            trapeze(MARCHE_AVANT);
            trapeze(MARCHE_AVANT);
            trapeze(MARCHE_AVANT);
            trapeze(MARCHE_AVANT);

//           faire_des_tours(-32);
            while(1);
////
////            TIMER_DEBUG = ACTIVE;
//            init_position_robot(0, 0, 0);
            ////Horraire
//       rejoindre(2000, 0, MARCHE_AVANT, 50);
//       orienter(90, 50);
//        rejoindre(300, 0, MARCHE_AVANT, 50);
//        orienter(-90, 50);
//        rejoindre(2000, 0, MARCHE_AVANT, 50);
//        orienter(90, 50);
//        rejoindre(300, 0, MARCHE_AVANT, 50);
//        orienter (-90, 50);
//        rejoindre(2000, 0, MARCHE_AVANT, 50);
//        orienter(90, 50);
//        rejoindre(300, 0, MARCHE_AVANT, 50);
//        orienter (-90, 50);
//        rejoindre(2000, 0, MARCHE_AVANT, 50);
//        orienter(90, 50);
//        rejoindre(300, 0, MARCHE_AVANT, 50);
//        orienter (-90, 50);
//        rejoindre(2000, 0, MARCHE_AVANT, 50);
//        orienter(90, 50);
//        rejoindre(300, 0, MARCHE_AVANT, 50);
//        orienter (-90, 50);
//        rejoindre(2000, 0, MARCHE_AVANT, 50);
//        orienter(90, 50);
//        rejoindre(300, 0, MARCHE_AVANT, 50);
//        orienter(-90, 50);


            //// Anti horaire
        rejoindre(2000, 0, MARCHE_AVANT, 50);
        orienter(-90, 50);
        rejoindre(300, 0, MARCHE_AVANT, 50);
        orienter(90, 50);
        rejoindre(2000, 0, MARCHE_AVANT, 50);
        orienter(-90, 50);
        rejoindre(300, 0, MARCHE_AVANT, 50);
        orienter (90, 50);
        rejoindre(2000, 0, MARCHE_AVANT, 50);
        orienter(-90, 50);
        rejoindre(300, 0, MARCHE_AVANT, 50);
        orienter (90, 50);
        rejoindre(2000, 0, MARCHE_AVANT, 50);
        orienter(-90, 50);
        rejoindre(300, 0, MARCHE_AVANT, 50);
        orienter (90, 50);
        rejoindre(2000, 0, MARCHE_AVANT, 50);
        orienter(-90, 50);
        rejoindre(300, 0, MARCHE_AVANT, 50);
        orienter (90, 50);
        rejoindre(2000, 0, MARCHE_AVANT, 50);
        orienter(-90, 50);
        rejoindre(300, 0, MARCHE_AVANT, 50);
        orienter(90, 50);
        rejoindre(500, 0, MARCHE_AVANT, 100);


//        rejoindre(2000, 0, MARCHE_AVANT, 100);
//        rejoindre(300, 0, MARCHE_AVANT, 100);
//        rejoindre(2000, 0, MARCHE_AVANT, 100);
//        rejoindre(300, 0, MARCHE_AVANT, 100);
//        rejoindre(2000, 0, MARCHE_AVANT, 100);
//        rejoindre(300, 0, MARCHE_AVANT, 100);
//        rejoindre(2000, 0, MARCHE_AVANT, 100);
//        rejoindre(300, 0, MARCHE_AVANT, 100);
//        rejoindre(2000, 0, MARCHE_AVANT, 100);
//        rejoindre(300, 0, MARCHE_AVANT, 100);
//        rejoindre(2000, 0, MARCHE_AVANT, 100);
//        rejoindre(300, 0, MARCHE_AVANT, 100);
//        rejoindre(2000, 0, MARCHE_AVANT, 100);
//        rejoindre(300, 0, MARCHE_AVANT, 100);
//        rejoindre(500, 0, MARCHE_AVANT, 100);
//        TIMER_DEBUG = DESACTIVE;

        delay_ms(10000);
}